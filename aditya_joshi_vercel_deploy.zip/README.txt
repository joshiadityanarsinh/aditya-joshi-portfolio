Aditya Joshi Portfolio — Vercel deployment

This is a static HTML website.
To publish: create/import a Git repository containing index.html, then import that repository in Vercel.
Vercel framework preset: Other. Build command: leave blank. Output directory: leave blank / root.
Before publishing, replace the example email address in index.html with your actual email.
